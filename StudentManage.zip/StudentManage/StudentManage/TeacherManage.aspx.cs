﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManage
{
    public partial class TeacherManage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //未登录
            if (Request.Cookies["sno"] == null && Request.Cookies["tno"] == null && Request.Cookies["role"] == null)
            {
                Response.Redirect("Login.aspx?msg=" + Server.UrlEncode("您尚未登录，请先登录"));
            }
            string myName1Value = null;
            if (Request.Cookies["role"] != null)
            {
                myName1Value = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["role"].Value);
                if (myName1Value == "分管教学领导")
                {
                    String dept = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["department"].Value);
                    SqlDataSource1.SelectCommand = "SELECT tno,password,tname,sex,email,department FROM [teacher] where department='" + dept + "'";
                }
            }
        }
    }
}