﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManage
{
    public partial class EditUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string myName1Value = null;
            if (Request.Cookies["role"] != null)
            {
                myName1Value = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["role"].Value);
                if (myName1Value != "系统管理员")
                {
                    Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
                }
            }
            else
            {
                Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
            }
        }
    }
}