﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManage
{
    public partial class SearchGrade : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //权限管理
            if (Request.Cookies["tno"] == null)
            {
                Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
       
            }
            if (Request.Cookies["sno"] == null && Request.Cookies["tno"] == null && Request.Cookies["role"] == null)
            {
                Response.Redirect("Login.aspx?msg=" + Server.UrlEncode("您尚未登录，请先登录"));
            }
            if (txtSno.Text.Trim()== "" && txtCname.Text.Trim() == "")
            {
                SqlDataSource1.SelectParameters["sno"].ConvertEmptyStringToNull = true;
                SqlDataSource1.SelectParameters["cname"].ConvertEmptyStringToNull = true;
             }
            else
            {
                SqlDataSource1.SelectParameters["sno"].ConvertEmptyStringToNull = false;
                SqlDataSource1.SelectParameters["cname"].ConvertEmptyStringToNull = false;
                if (txtCname.Text.Trim() == "")
                {
                    SqlDataSource1.SelectCommand = "SELECT student_course.sno, course.cname, student_course.cno, student_course.score  FROM student_course, course where(student_course.cno=course.cno and (sno=@sno))";
                }
                else if (txtSno.Text.Trim() == "")
                {
                    SqlDataSource1.SelectCommand = "SELECT student_course.sno, course.cname, student_course.cno, student_course.score  FROM student_course, course where(student_course.cno=course.cno and (cname=@cname))";
                }
                else
                {
                    SqlDataSource1.SelectCommand = "SELECT student_course.sno, course.cname, student_course.cno, student_course.score  FROM student_course, course where(student_course.cno=course.cno and (cname=@cname and sno=@sno))";
                }
            }

        }
    }
}