﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManage
{
    public partial class SearchCourse : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["role"] == null)
            {
                Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
            }
        }
    }
}