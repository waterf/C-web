﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace StudentManage
{
    public partial class AddGrade : System.Web.UI.Page
    {
        SqlConnection cn = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            //权限管理
            if (Request.Cookies["tno"] == null)
            {
                Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
       
            }
            //未登录
            if (Request.Cookies["sno"] == null && Request.Cookies["tno"] == null && Request.Cookies["role"] == null)
            {
                Response.Redirect("Login.aspx?msg=" + Server.UrlEncode("您尚未登录，请先登录"));
            }

            string strconn = ConfigurationManager.ConnectionStrings["studbConnectionString"].ConnectionString;
            cn = new SqlConnection(strconn);
        }

       
        protected void btnOK_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                cn.Open();
                string strsql = "insert into student_course(sno, cno, score) values(@sno, @cno, @score)";
                SqlCommand cm = new SqlCommand(strsql, cn);

                cm.Parameters.Add(new SqlParameter("@sno", SqlDbType.Char, 10));
                cm.Parameters.Add(new SqlParameter("@cno", SqlDbType.Char, 10));
                cm.Parameters.Add(new SqlParameter("@score", SqlDbType.TinyInt));
                
                cm.Parameters["@sno"].Value = txtSno.Text;
                cm.Parameters["@cno"].Value = txtCno.Text;
                cm.Parameters["@score"].Value = txtScore.Text;
                try
                {
                    cm.ExecuteNonQuery();
                    cn.Close();
                    Response.Redirect("EditGrade.aspx");

                }
                catch (SqlException)
                {
                    lblTooltip.Text = "添加失败";
                }
                cn.Close();
            }
        }


        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("EditGrade.aspx");
        }
    }
}