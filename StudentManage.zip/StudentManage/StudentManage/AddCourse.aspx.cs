﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace StudentManage
{
    public partial class AddCourse : System.Web.UI.Page
    {
        SqlConnection cn = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            //未登录
            if (Request.Cookies["sno"] == null && Request.Cookies["tno"] == null && Request.Cookies["role"] == null)
            {
                Response.Redirect("Login.aspx?msg=" + Server.UrlEncode("您尚未登录，请先登录"));
            }
            //权限管理
            
            if (Request.Cookies["role"] == null)
            {
                Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
            }
            string strconn = ConfigurationManager.ConnectionStrings["studbConnectionString"].ConnectionString;
            cn = new SqlConnection(strconn);
        }

        // 检查输入的“用户ID”是否在SysUser表中存在，如果存在，则验证失败，否则验证通过
        // 注意，自定义控件的验证是在服务器端执行的
        protected void cvID_ServerValidate(object source, ServerValidateEventArgs args)
        {
            cn.Open();
            string strsql = "SELECT * FROM course WHERE cno=@cno";
            SqlCommand cm = new SqlCommand(strsql, cn);
            cm.Parameters.Add(new SqlParameter("@cno", SqlDbType.Char, 10));
            cm.Parameters["@cno"].Value = txtCno.Text;

            SqlDataReader dr = cm.ExecuteReader();
            args.IsValid = !dr.Read();
            cn.Close();
        }

        // 使用SQL语句在Sysuser表中插入一条记录
        protected void btnOK_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                cn.Open();

                string strsql = "INSERT INTO course(cno, spno, cname, lecture, semester, credit, tno) VALUES(@cno, @spno, @cname, @lecture, @semester, @credit,@tno)";
                SqlCommand cm = new SqlCommand(strsql, cn);

                cm.Parameters.Add(new SqlParameter("@cno", SqlDbType.Char, 10));
                cm.Parameters.Add(new SqlParameter("@spno", SqlDbType.Char, 8));
                cm.Parameters.Add(new SqlParameter("@cname", SqlDbType.Char, 20));
                cm.Parameters.Add(new SqlParameter("@lecture", SqlDbType.TinyInt));
                cm.Parameters.Add(new SqlParameter("@semester", SqlDbType.TinyInt));
                cm.Parameters.Add(new SqlParameter("@credit", SqlDbType.TinyInt));
                cm.Parameters.Add(new SqlParameter("@tno", SqlDbType.NVarChar, 10));
                

                cm.Parameters["@cno"].Value = txtCno.Text;
                cm.Parameters["@spno"].Value = txtSpno.Text;
                cm.Parameters["@cname"].Value = txtCname.Text;
                cm.Parameters["@lecture"].Value = txtLecture.Text;
                cm.Parameters["@semester"].Value = txtSemester.Text;
                cm.Parameters["@credit"].Value = txtCredit.Text;
                cm.Parameters["@tno"].Value = txtTno.Text;
               
                try
                {
                    cm.ExecuteNonQuery();
                    cn.Close();
                    Response.Redirect("EditCourse.aspx");

                }
                catch (SqlException)
                {
                    lblTooltip.Text = "添加失败";
                }
                cn.Close();
            }
        }


        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("EditCourse.aspx");
        }

        protected void btnSnoSearch_Click(object sender, EventArgs e)
        {

        }

        protected void btnCnoSearch_Click(object sender, EventArgs e)
        {

        }
    }
}