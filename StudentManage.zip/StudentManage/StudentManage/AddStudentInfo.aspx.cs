﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Configuration;
using System.Data.SqlClient;

namespace StudentManage
{
    public partial class AddStudentInfo : System.Web.UI.Page
    {
        SqlConnection cn = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            //未登录
            if (Request.Cookies["sno"] == null && Request.Cookies["tno"] == null && Request.Cookies["role"] == null)
            {
                Response.Redirect("Login.aspx?msg=" + Server.UrlEncode("您尚未登录，请先登录"));
            }
            //权限管理
            string myName1Value = null;
            if (Request.Cookies["role"] != null)
            {
                myName1Value = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["role"].Value);
                if (myName1Value == "系统管理员" || myName1Value == "教务秘书")
                {
                }
                else 
                {
                    Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
                }
            }
            else{
                Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
            }
            
            string strconn = ConfigurationManager.ConnectionStrings["studbConnectionString"].ConnectionString;
            cn = new SqlConnection(strconn);
        }

        // 检查输入的“用户ID”是否在SysUser表中存在，如果存在，则验证失败，否则验证通过
        // 注意，自定义控件的验证是在服务器端执行的
        protected void cvID_ServerValidate(object source, ServerValidateEventArgs args)
        {
            cn.Open();
            string strsql = "SELECT * FROM student WHERE sno=@sno";
            SqlCommand cm = new SqlCommand(strsql, cn);
            cm.Parameters.Add(new SqlParameter("@sno", SqlDbType.Char, 10));
            cm.Parameters["@sno"].Value = txtSno.Text;

            SqlDataReader dr = cm.ExecuteReader();
            args.IsValid = !dr.Read();
            cn.Close();
        }

        // 使用SQL语句在Sysuser表中插入一条记录
        protected void btnOK_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                cn.Open();
                string strsql = "INSERT INTO student(sno, sname, sex, birthday, dept, spno, classno, password) VALUES(@sno, @sname, @sex, @birthday, @dept, @spno,@classno, @password)";
                SqlCommand cm = new SqlCommand(strsql, cn);

                cm.Parameters.Add(new SqlParameter("@sno", SqlDbType.Char, 10));
                cm.Parameters.Add(new SqlParameter("@sname", SqlDbType.Char, 8));
                cm.Parameters.Add(new SqlParameter("@sex", SqlDbType.Char, 2));
                cm.Parameters.Add(new SqlParameter("@birthday", SqlDbType.Date));
                cm.Parameters.Add(new SqlParameter("@dept", SqlDbType.VarChar, 50));
                cm.Parameters.Add(new SqlParameter("@spno", SqlDbType.Char, 8));
                cm.Parameters.Add(new SqlParameter("@classno", SqlDbType.Char, 10));
                cm.Parameters.Add(new SqlParameter("@password", SqlDbType.NVarChar, 10));

                cm.Parameters["@sno"].Value = txtSno.Text;
                cm.Parameters["@sname"].Value = txtSname.Text;
                cm.Parameters["@sex"].Value = txtSex.Text;
                cm.Parameters["@birthday"].Value = txtBirthday.Text;
                cm.Parameters["@dept"].Value = txtDept.Text;
                cm.Parameters["@spno"].Value = txtSpno.Text;
                cm.Parameters["@classno"].Value = txtClassno.Text;
                cm.Parameters["@password"].Value =txtPwd.Text;
                try
                {
                    cm.ExecuteNonQuery();
                    cn.Close();
                    Response.Redirect("EditStudentInfo.aspx");

                }
                catch (SqlException)
                {
                    lblTooltip.Text = "添加失败";
                }
                cn.Close();
            }
        }


        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("EditStudentInfo.aspx");
        }

    }
}