﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManage
{
    public partial class SearchTeacherInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (txtTno.Text.Trim() == "" && txtTname.Text.Trim() == "" && txtDept.Text.Trim() == "")
            {
                SqlDataSource1.SelectParameters["tno"].ConvertEmptyStringToNull = true;
                SqlDataSource1.SelectParameters["tname"].ConvertEmptyStringToNull = true;
                SqlDataSource1.SelectParameters["department"].ConvertEmptyStringToNull = true;
            }
            else
            {
               
                SqlDataSource1.SelectParameters["tno"].ConvertEmptyStringToNull = false;
                SqlDataSource1.SelectParameters["tname"].ConvertEmptyStringToNull = false;
                SqlDataSource1.SelectParameters["department"].ConvertEmptyStringToNull = false;
                if (txtTno.Text.Trim() == "" && txtTname.Text.Trim() != "" & txtDept.Text.Trim() != "")
                {
                    SqlDataSource1.SelectCommand = "SELECT * FROM [teacher] where((tname=@tname) and (department=@department) )";
                }
                else if (txtTno.Text.Trim() != "" && txtTname.Text.Trim() == "" & txtDept.Text.Trim() != "")
                {
                    SqlDataSource1.SelectCommand = "SELECT * FROM [teacher] where((tno=@tno) and (department=@department) )";
                }
                else if (txtTno.Text.Trim() != "" && txtTname.Text.Trim() != "" & txtDept.Text.Trim() == "")
                {
                    SqlDataSource1.SelectCommand = "SELECT * FROM [teacher] where((tno=@tno) and (tname=@tname) )";
                }
                else if (txtTno.Text.Trim() != "" && txtTname.Text.Trim() == "" & txtDept.Text.Trim() == "")
                {
                    SqlDataSource1.SelectCommand = "SELECT * FROM [teacher] where((tno=@tno))";
                }
                else if (txtTno.Text.Trim() == "" && txtTname.Text.Trim() != "" & txtDept.Text.Trim() == "")
                {
                    SqlDataSource1.SelectCommand = "SELECT * FROM [teacher] where((tname=@tname))";
                }
                else if (txtTno.Text.Trim() == "" && txtTname.Text.Trim() == "" & txtDept.Text.Trim() != "")
                {
                    SqlDataSource1.SelectCommand = "SELECT * FROM [teacher] where((department=@department) )";
                }
                else
                {
                    SqlDataSource1.SelectCommand = "SELECT * FROM [teacher] where((tno=@tno) and (tname=@tname) and (department=@department) )";
                }
            }
            string myName1Value = null;
            if (Request.Cookies["role"] != null)
            {
                myName1Value = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["role"].Value);
                if (myName1Value == "分管教学领导")
                {
                    Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
                }
            }
            else
            {
                Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
            }
        }
    }
}