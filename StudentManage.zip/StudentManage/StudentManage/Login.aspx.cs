﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Configuration;

namespace StudentManage
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            //string msg = Request.QueryString["msg"];
            //if (!string.IsNullOrEmpty(msg)) ClientScript.RegisterStartupScript(GetType(), "error", "<script>alert('" + msg + "');</script>");
           
            Session["CurrentPage"] = "Login.aspx";
        }

        protected void SystemUserLogin_Click(object sender, EventArgs e)
        {
            string UserName = txtUserName.Text.Replace("'", "''");
            string Password = txtPassword.Text.Replace("'", "''");
            string txtImage = txtImgValid.Text.Replace("'", "''");

            string strconn = ConfigurationManager.ConnectionStrings["studbConnectionString"].ConnectionString;

            SqlConnection conn = new SqlConnection(strconn);
            conn.Open();
            //储存登录者信息
            string strsql = string.Format("SELECT * FROM sys_user WHERE userid='{0}' AND password='{1}'", UserName, Password);
            //Response.Write(strsql);
            //return;

            SqlCommand cm = new SqlCommand(strsql, conn);
            SqlDataReader dr = cm.ExecuteReader();
            if (dr.Read())
            {
                if (String.Compare(Session["CheckCode"].ToString(), txtImage, true) == 0)
                {
                    HttpCookie objCookie1;
                    HttpCookie objCookie2;
                    HttpCookie objCookie3;
                    if (dr["role"] != null)
                    {
                        objCookie1 = new HttpCookie("role", System.Web.HttpContext.Current.Server.UrlEncode(dr["role"].ToString()));
                        Response.Cookies.Add(objCookie1);
                        objCookie2 = new HttpCookie("department", System.Web.HttpContext.Current.Server.UrlEncode(dr["department"].ToString()));
                        Response.Cookies.Add(objCookie2);
                        objCookie3 = new HttpCookie("userid", System.Web.HttpContext.Current.Server.UrlEncode(dr["userid"].ToString()));
                        Response.Cookies.Add(objCookie3);
                    }
                    Response.Redirect("Default.aspx");
                }
            }
            else
                lblNote.Text = "用户名或密码不正确，登录失败！";
        }

        protected void TeacherLogin_Click(object sender, EventArgs e)
        {
            string UserName = txtUserName.Text.Replace("'", "''");
            string Password = txtPassword.Text.Replace("'", "''");
            string txtImage = txtImgValid.Text.Replace("'", "''");

            string strconn = ConfigurationManager.ConnectionStrings["studbConnectionString"].ConnectionString;

            SqlConnection conn = new SqlConnection(strconn);
            conn.Open();
            string strsql = string.Format("SELECT * FROM teacher WHERE tno='{0}' AND password='{1}'", UserName, Password);
            //Response.Write(strsql);
            //return;

            SqlCommand cm = new SqlCommand(strsql, conn);
            SqlDataReader dr = cm.ExecuteReader();
            if (dr.Read())
            {
                if (String.Compare(Session["CheckCode"].ToString(), txtImage, true) == 0)
                {
                    HttpCookie objCookie;
                    if (dr["tno"] != null)
                    {
                        objCookie = new HttpCookie("tno", System.Web.HttpContext.Current.Server.UrlEncode(dr["tno"].ToString()));
                        Response.Cookies.Add(objCookie);
                    }
                    Response.Redirect("Default.aspx");
                }
            }
            else
                lblNote.Text = "用户名或密码不正确，登录失败！";
        }

        protected void StudentLogin_Click(object sender, EventArgs e)
        {
            string UserName = txtUserName.Text.Replace("'", "''");
            string Password = txtPassword.Text.Replace("'", "''");
            string txtImage = txtImgValid.Text.Replace("'", "''");

            string strconn = ConfigurationManager.ConnectionStrings["studbConnectionString"].ConnectionString;

            SqlConnection conn = new SqlConnection(strconn);
            conn.Open();
            string strsql = string.Format("SELECT * FROM student WHERE sno='{0}' AND password='{1}'", UserName, Password);
            //Response.Write(strsql);
            //return;

            SqlCommand cm = new SqlCommand(strsql, conn);
            SqlDataReader dr = cm.ExecuteReader();
            
            if (dr.Read())
            {
                if (String.Compare(Session["CheckCode"].ToString(), txtImage, true) == 0)
                {
                   
                    HttpCookie objCookie;
                    if (dr["sno"] != null)
                    {
                        objCookie = new HttpCookie("sno", System.Web.HttpContext.Current.Server.UrlEncode(dr["sno"].ToString()));
                        Response.Cookies.Add(objCookie);
                    }
                    Response.Redirect("Default.aspx");
                }
            }
            else
                lblNote.Text = "用户名或密码不正确，登录失败！";
        }

    }
}