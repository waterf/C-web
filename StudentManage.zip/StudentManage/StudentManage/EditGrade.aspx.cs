﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManage
{
    public partial class EditGrade : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //权限管理
            if (Request.Cookies["tno"] == null)
            {
                Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
       
            }
            //只能管理自己所授课程
            else 
            {
                string tno = null;
                tno = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["tno"].Value);
                SqlDataSource1.SelectCommand = "SELECT student_course.sno, course.cname, student_course.cno, student_course.score  FROM student_course, course where(student_course.cno=course.cno and course.tno='" + tno + "')";    
            }
        }
    }
}