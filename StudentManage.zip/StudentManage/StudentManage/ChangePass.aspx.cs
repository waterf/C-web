﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Configuration;

namespace StudentManage
{
    public partial class ChangePass : System.Web.UI.Page
    {
        protected string userID;//user
        protected string tno;//teacher
        protected string sno;//student

        protected int charType(char num)
        {
            if (num >= 48 && num <= 57)
            {
                return 1;
            }
            if (num >= 97 && num <= 122)
            {
                return 2;
            }
            if (num >= 65 && num <= 90)
            {
                return 4;
            }
            return 8;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Cookies["sno"] == null && Request.Cookies["role"] == null && Request.Cookies["tno"] == null)
            {
                Response.Redirect("Login.aspx?msg=" + Server.UrlEncode("您尚未登陆，请登入后再操作！"));
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //定义int tabIndex=1, 2, 3代表三个表再搜索更新
            if (null != Request.Cookies["userid"])
            {
                userID = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["userid"].Value);
            }
            if (null != Request.Cookies["tno"])
            {
                tno = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["tno"].Value);
            }
            if (null != Request.Cookies["sno"])
            {
                sno = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["sno"].Value);
            }
         
            string CurrentPwd = oldpwd.Text.Trim().Replace("'", "''");
            string NewPwd = newpwd.Text.Trim().Replace("'", "''");
            string ConfirmPwd = confirmtxt.Text.Trim().Replace("'", "''");
            string UserPwd = "";

            int len = NewPwd.Length;
            int i = 0;
            int tabIndex = 0;
            int level = 0;
            int result = 0;


            for (i = 0; i < len; i++)
            {
                result |= charType(NewPwd[i]);
            }


            for (i = 0; i <= 4; i++)
            {
                if ((result & 1) != 0)
                {
                    level++;
                }
                result = result >> 1;
            }

            string strConn = ConfigurationManager.ConnectionStrings["studbConnectionString"].ConnectionString;
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            string strSql_user = "SELECT password FROM sys_user WHERE userid ='" + userID + "'";
            string strSql_teacher = "SELECT password FROM teacher WHERE tno ='" + tno + "'";
            string strSql_student = "SELECT password FROM student WHERE sno ='" + sno + "'";
            //Response.Write(strSql);
            SqlCommand myCommand = new SqlCommand(strSql_student, conn);
            SqlDataReader dr = myCommand.ExecuteReader();
            if (!dr.Read())
            {
                dr.Close();
                myCommand = new SqlCommand(strSql_teacher, conn);
                dr = myCommand.ExecuteReader();
                if (!dr.Read())
                {
                    dr.Close();
                    myCommand = new SqlCommand(strSql_user, conn);
                    dr = myCommand.ExecuteReader();
                
                    if(dr.Read()) 
                    {
                        tabIndex = 1;
                        UserPwd = dr["password"].ToString().Trim();
                    }
                }
                else 
                {
                    tabIndex = 2;
                    UserPwd = dr["password"].ToString().Trim();
                }
            }
            else 
            {
                tabIndex = 3;
                UserPwd = dr["password"].ToString().Trim();
            }

            dr.Close();

            if (UserPwd != CurrentPwd)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "error", "<script>alert('原密码错误！')</script>");

            }
            else
            {
                if (NewPwd != ConfirmPwd)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "error", "<script>alert('两次输入密码不一致！')</script>");
                }
                else if (NewPwd.Length < 6)
                {

                    ClientScript.RegisterStartupScript(this.GetType(), "error", "<script>alert('密码长度必须大于6！')</script>");
                }
                else if (level == 1)
                {

                    ClientScript.RegisterStartupScript(this.GetType(), "error", "<script>alert('密码强度太弱！')</script>");
                }
                else
                {
                    string strSql2="";
                    if (1 == tabIndex)
                    {
                        strSql2 = "UPDATE sys_user SET password = '" + NewPwd + "'  WHERE userid ='" + userID + "'";
                    }
                    else if (2 == tabIndex)
                    {
                        strSql2 = "UPDATE teacher SET password = '" + NewPwd + "'  WHERE tno ='" + tno + "'";
                    }
                    else if(3==tabIndex)
                    {
                        strSql2 = "UPDATE student SET password = '" + NewPwd + "'  WHERE sno ='" + sno + "'";
                    }
                    SqlCommand myCommand2 = new SqlCommand(strSql2, conn);
                    myCommand2.ExecuteNonQuery();
                    Response.Redirect("StudentManage.aspx");
                }
            }
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("StudentManage.aspx");
        }
    }
}