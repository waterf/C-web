﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManage
{
    public partial class SearchStudentInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //未登录
            if (Request.Cookies["sno"] == null && Request.Cookies["tno"] == null && Request.Cookies["role"] == null)
            {
                Response.Redirect("Login.aspx?msg=" + Server.UrlEncode("您尚未登录，请先登录"));
            }
             // SelectCommand="SELECT sno, sname, sex, birthday, dept, spno, classno FROM [student] where(sno=@sno or sname=@sname or dept=@dept)";
  
            if (txtSno.Text.Trim() == "" && txtSname.Text.Trim() == "" && txtDept.Text.Trim() == "")
            {
                SqlDataSource1.SelectParameters["sno"].ConvertEmptyStringToNull = true;
                SqlDataSource1.SelectParameters["sname"].ConvertEmptyStringToNull = true;
                SqlDataSource1.SelectParameters["dept"].ConvertEmptyStringToNull = true;
            }
            else
            {
                SqlDataSource1.SelectParameters["sno"].ConvertEmptyStringToNull = false;
                SqlDataSource1.SelectParameters["sname"].ConvertEmptyStringToNull = false;
                SqlDataSource1.SelectParameters["dept"].ConvertEmptyStringToNull = false;
                if (txtSno.Text.Trim() == "" && txtSname.Text.Trim() != "" & txtDept.Text.Trim() != "")
                {
                    SqlDataSource1.SelectCommand = "SELECT sno, sname, sex, birthday, dept, spno, classno FROM [student] where(sname=@sname and dept=@dept)";
                }
                else if (txtSno.Text.Trim() != "" && txtSname.Text.Trim() == "" & txtDept.Text.Trim() != "")
                {
                    SqlDataSource1.SelectCommand = "SELECT sno, sname, sex, birthday, dept, spno, classno FROM [student] where(sno=@sno and dept=@dept)";
                }
                else if (txtSno.Text.Trim() != "" && txtSname.Text.Trim() != "" & txtDept.Text.Trim() == "")
                {
                    SqlDataSource1.SelectCommand = "SELECT sno, sname, sex, birthday, dept, spno, classno FROM [student] where(sno=@sno and sname=@sname)";
                }
                else if (txtSno.Text.Trim() != "" && txtSname.Text.Trim() == "" & txtDept.Text.Trim() == "")
                {
                    SqlDataSource1.SelectCommand = "SELECT sno, sname, sex, birthday, dept, spno, classno FROM [student] where(sno=@sno)";
                }
                else if (txtSno.Text.Trim() == "" && txtSname.Text.Trim() != "" & txtDept.Text.Trim() == "")
                {
                    SqlDataSource1.SelectCommand = "SELECT sno, sname, sex, birthday, dept, spno, classno FROM [student] where(sname=@sname)";
                }
                else if (txtSno.Text.Trim() == "" && txtSname.Text.Trim() == "" & txtDept.Text.Trim() != "")
                {
                    SqlDataSource1.SelectCommand = "SELECT sno, sname, sex, birthday, dept, spno, classno FROM [student] where(dept=@dept)";
                }
                else 
                {
                    SqlDataSource1.SelectCommand = "SELECT sno, sname, sex, birthday, dept, spno, classno FROM [student] where(dept=@dept and sno=@sno and sname=@sname)";
                }
            }
             string myName1Value = null;
             if (Request.Cookies["role"] != null)
             {
                 myName1Value = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["role"].Value);
                 if (myName1Value == "分管教学领导")
                 {
                     Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
                 }
             }
             else
             {
                 Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
             }
        }
    }
}