﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManage
{
    public partial class MasterPage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string myName1Value = null;
            if (Request.Cookies["tno"] != null)
            {
                myName1Value = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["tno"].Value);
            }
            if (Request.Cookies["sno"] != null)
            {
                myName1Value = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["sno"].Value);
            }
            if (Request.Cookies["userid"] != null)
            {
                myName1Value = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["userid"].Value);
            }
            lblTooltip.Text = "欢迎, " + myName1Value;
        }

        protected void ContentPlaceHolder1_PreRender(object sender, EventArgs e)
        {
            string msg = Request.QueryString["msg"];
            if (!string.IsNullOrEmpty(msg)) Page.ClientScript.RegisterStartupScript(GetType(), "error", "<script>alert('" + msg + "');</script>");
        }

        protected void DeleteCookie_Click(object sender, EventArgs e)
        {
            HttpCookie cok1 = Request.Cookies["sno"];
            HttpCookie cok2 = Request.Cookies["tno"];
            HttpCookie cok3 = Request.Cookies["role"];
            HttpCookie cok4 = Request.Cookies["department"];
            HttpCookie cok5 = Request.Cookies["userid"];

            if (cok1 != null)
            {
                TimeSpan ts = new TimeSpan(-1, 0, 0, 0);
                cok1.Expires = DateTime.Now.Add(ts);//删除整个Cookie，只要把过期时间设置为现在
                Response.AppendCookie(cok1);
            }
            if (cok2 != null)
            {
                TimeSpan ts = new TimeSpan(-1, 0, 0, 0);
                cok2.Expires = DateTime.Now.Add(ts);//删除整个Cookie，只要把过期时间设置为现在
                Response.AppendCookie(cok2);
            }
            if (cok3 != null)
            {
                TimeSpan ts = new TimeSpan(-1, 0, 0, 0);
                cok3.Expires = DateTime.Now.Add(ts);//删除整个Cookie，只要把过期时间设置为现在
                Response.AppendCookie(cok3);
            }
            if (cok4 != null)
            {
                TimeSpan ts = new TimeSpan(-1, 0, 0, 0);
                cok4.Expires = DateTime.Now.Add(ts);//删除整个Cookie，只要把过期时间设置为现在
                Response.AppendCookie(cok4);
            }
            if (cok5 != null)
            {
                TimeSpan ts = new TimeSpan(-1, 0, 0, 0);
                cok5.Expires = DateTime.Now.Add(ts);//删除整个Cookie，只要把过期时间设置为现在
                Response.AppendCookie(cok5);
            }
          
            Response.Redirect("Login.aspx");
        }
    }
}