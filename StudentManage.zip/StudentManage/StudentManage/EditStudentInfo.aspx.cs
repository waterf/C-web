﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StudentManage
{
    public partial class EditStudentInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string myName1Value = null;
            if (Request.Cookies["role"] != null)
            {
                myName1Value = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["role"].Value);
                if (myName1Value == "分管教学领导")
                {
                    Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
                }
                if (myName1Value == "系统管理员")
                {
                    SqlDataSource1.SelectCommand = "select sno,sname,sex,birthday,dept,spno, classno from [student]";
                }
               if (myName1Value == "教务秘书")
                {
                    String dept = null;
                    if (Request.Cookies["department"] != null)
                    {
                        dept = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["department"].Value);
                        SqlDataSource1.SelectCommand = "select sno,sname,sex,birthday,dept,spno, classno from [student] where dept='" + dept + "'";
                    }
                 }
            }
            if (Request.Cookies["sno"] != null)
            {
                String sno = System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["sno"].Value);
                SqlDataSource1.SelectCommand = "select sno,sname,sex,birthday,dept,spno, classno from [student] where sno='" + sno + "'";
            }
            if (Request.Cookies["tno"] != null)
            {
                Response.Redirect("Default.aspx?msg=" + Server.UrlEncode("您不是合法用户，请重新登入后再操作！"));
            }
           
        }
    }
}